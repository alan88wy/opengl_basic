#pragma once

const int MAX_POINT_LIGHTS = 3;